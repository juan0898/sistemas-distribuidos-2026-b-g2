# Billing Service

> Own catalog prices, justified care-time manual prices, billable snapshots, invoices, balances and internally recorded payments.

## Location in the architecture

| Field | Value |
|---|---|
| Number in catalog | 06 |
| Classification | Business |
| Responsible person | Juan Diego Mora |
| Technology | Java / Spring Boot |
| Local port | Pending verification in the API repository |
| DB engine | Shared PostgreSQL schema billing |
| Communicates with | Patients references, Auth eligibility, Appointments current relationship, Clinical completion events, PostgreSQL and RabbitMQ. |
| Status | Target design documented; runtime acceptance not verified |

## Responsibilities (what this service DOES)

- Administrator maintains versioned global base/additional price rules.
- Dentist/Administrator records manual care prices with mandatory justification, actor/time and clinical-source reference; Dentist requires current care authority.
- Reconcile manual or catalog price once per source after clinical completion; never create a second base charge.
- Assistant/Administrator issues invoices and records positive internal/simulated payments within the outstanding balance.
- Preserve immutable issued values; expose minimized financial labels without clinical narrative.
- Publish financial facts through local outbox and reject concurrent stale/duplicate mutations safely.

## Out of scope (what it does NOT do)

- Clinical data and procedure authorship belong to Clinical; no Clinical service sends monetary fields.
- Assistant cannot enter/edit manual prices; Dentist does not issue invoices or record payments.
- Real payment-gateway integration and electronic tax invoicing are excluded.

## Component repositories

| Component | Repository | Responsibility |
|---|---|---|
| Database | [dlc-billing-db](https://github.com/code-corhuila/dlc-billing-db) | Owned schemas/validators, indexes, migrations and synthetic seeds; no independent business API |
| API | [dlc-billing-api](https://github.com/code-corhuila/dlc-billing-api) | Hexagonal domain/application logic, owner HTTP/event contracts and infrastructure adapters |
| Portal | [dlc-billing-portal](https://github.com/code-corhuila/dlc-billing-portal) | Authorized staff workflows using owner APIs; UI permissions never replace server authorization |

These are components of one service context, not three additional microservices. See the dated [repository evidence register](../../repository-evidence.md). Repository links are supplied by the project owner; a link is not evidence of a working service.

## How to run it locally

No startup command is represented as verified. First obtain the recorded API/DB/portal revision, confirm its runtime manifest and configuration, select synthetic data and check owned datastore grants. Apply only the owner's reviewed migrations, then start required dependencies and the API, and validate private liveness/readiness before connecting the portal. Exact environment keys, ports, launch instructions and successful observations must be recorded from the repositories before claiming a reproducible setup. The temporary prototype is not used as a substitute.

## Related documents

- [data-model.md](data-model.md) — owned fields, constraints and evolution.
- [events.md](events.md) — producer/consumer responsibilities and transport.
- [decisions.md](decisions.md) — service decisions and unresolved implementation gates.
- [runbook.md](runbook.md) — health, diagnosis, recovery and verification.
- [API contract](../../../07-api/contracts/openapi/billing-service.yaml).
- [Requirements](../../../04-requirements/user-stories.md) — HU-BIL-001 through HU-BIL-004; HU-XCT-001.

## Required environment configuration

| Concern | Required information; exact key names await repository verification |
|---|---|
| Persistence | Owned store endpoint, least-privileged credential and migration identity; secret values never documented |
| Identity | Issuer/audience and trusted key configuration; private service audience/scopes |
| Integration | Owner contract locations, broker credentials and declared queues/bindings |
| Operations | Private health endpoints, structured logs, correlation, metrics and environment label |
| Portal | Approved Gateway origin and the shared session/CSRF policy; no credentials in browser storage |
