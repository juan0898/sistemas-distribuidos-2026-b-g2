# Data Model — Billing Service

> Owner model under the approved design. Physical migrations are not verified; see [repository evidence](../../repository-evidence.md).

## Database engine

PostgreSQL schema billing supports exact decimal arithmetic, invoice/payment atomicity, source uniqueness and immutable issued snapshots. Monetary values use NUMERIC(14,2) with COP; HTTP contracts serialize exact decimal strings.

## Tables: procedure_prices and additional_price_rules

| Field | Type | Nullable | Constraint / purpose |
|---|---|---|---|
| price_id / rule_id | UUID | No | Owner identity |
| procedure_code / rule_code | Text | No | Catalog source key |
| base_price / unit_price | NUMERIC(14,2) | No | Positive exact amount |
| currency | Currency code | No | COP |
| valid_from / valid_to | Timestamp | End optional | No overlapping active validity for the same source |
| version / actor / audit time | Integer / UUID / timestamp | No | Audited catalog evolution |

Administrator maintains global catalog prices. New manual care prices require justified Dentist/Administrator entry, not a separate approval threshold. Legacy approval fields, if retained for historical compatibility, cannot force a second approval for those entries.

## Table: manual_charges

| Field | Type | Nullable | Constraint / purpose |
|---|---|---|---|
| charge_id / patient_id / appointment_id / procedure_id / source_record_id | UUID | No | Charge identity and validated care correlation |
| item_type | ChargeType | No | Base, material, procedure, complexity or other authorized charge |
| quantity | Exact decimal | No | Positive; never binary floating point |
| unit_price / currency | NUMERIC(14,2) / code | No | Positive COP amount |
| justification | Protected text | No | Required reason; not copied to front-desk narrative |
| recorded_by / recorded_at | UUID / timestamp | No | Server-derived Dentist/Administrator attribution |
| status / version | Enum / integer | No | PENDING_CLINICAL or READY; optimistic version |

Validate current care authority for Dentist. Assistant cannot enter/edit manual charges. A manual base price resolves the intended base source; it must not be added on top of another base snapshot. Pending clinical sources cannot be invoiced. Already finalized/issued sources are not silently repriced.

## Tables: billable_items, invoices and invoice_items

Billable items retain UUID identity, procedure/source keys, item type, quantity, applied unit price/currency, catalog version when used, justification and actor. Source keys prevent duplicate clinical-event/manual entries. Invoices retain UUID invoice/patient/appointment references, lifecycle, exact total/balance, version and audit. Invoice items reference unique previously unbilled items for one patient.

An issued invoice freezes its values. Later catalog changes affect future items only. Assistant/Administrator issues invoices using Billing totals; the client cannot provide trusted totals or clinical narrative. Corrections require auditable owner workflow without deleting history.

## Table: payments

| Field | Type | Nullable | Constraint / purpose |
|---|---|---|---|
| payment_id / invoice_id | UUID | No | Unique payment and owned invoice reference |
| amount | NUMERIC(14,2) | No | Positive and not above balance |
| method / reference | Code / text | Reference optional | Approved internal/simulated payment method |
| recorded_by / recorded_at | UUID / timestamp | No | Authorized administrative actor/time |
| idempotency identity / request hash | UUID / hash | No | Same payload returns prior result; changed payload conflicts |

Lock/version the invoice during payment to prevent concurrent overpayment. ISSUED/PARTIALLY_PAID invoices may accept payment; zero balance becomes PAID. No real payment-gateway integration is implied.

## Relationships

Clinical procedures and patient references remain contractual; no direct cross-owner reads/writes. Invoices own items and payments locally. Index patient/status/date and unique source/operation keys. Clinical and financial retention periods await institutional policy; no arbitrary purge.

## Inbox, outbox and audit

Owner-local integration records retain eventId, type/version, aggregate identity, payload, correlation/causation, publication/processing state, attempts and timestamps. Commit business state and outbox atomically; record inbox deduplication with the consumer write. Do not place credentials or clinical narrative in general-purpose payloads. Operation replay rechecks authorization before returning a saved result.

## Migrations

Concrete migration tooling and script paths await owner repository verification. PostgreSQL owner schemas share a coordinated global version sequence; Clinical MongoDB has its own sequence. Applied shared-environment migrations are immutable, production recovery is forward-corrective, and runtime users do not receive migration privileges. Preserve historical identifiers, grant boundaries and source uniqueness. Verify backup/restore and compatibility before incompatible change.

## Correlations

- [Owner runbook](runbook.md), [events](events.md) and [decisions](decisions.md).
- [Canonical models](../../../06-data/models.md), [dictionary](../../../06-data/data-dictionary.md) and [migration strategy](../../../06-data/migration-strategy.md).
- [Business rules](../../../02-domain/entities-and-rules.md) and [data ownership](../../data-ownership-matrix.md).
