# Design Decisions — Billing Service

These owner decisions apply the accepted architecture and [operating rules](../../../05-architecture/decisions/records/ADR-004-operating-rules.md). They describe intended behavior, not repository implementation.

## Decision: owned persistence and transactions

Context: business facts need one authority and reliable local changes. Decision: Shared PostgreSQL schema billing; only this owner writes its structures and outbox. Other services use contracts/events. Consequence: cross-owner workflows require explicit failure and reconciliation behavior rather than direct database fallback. Migration tool and runtime commands require repository verification.

## Decision: authorization at the owner boundary

Context: UI and Gateway checks cannot establish patient/resource authority. Decision: verify current identity and operation permission in the use case, and current Appointments relationship when required. Consequence: unavailable authority denies/defer access; negative and concurrent-revocation tests are release gates.

## Decision: reliable integration

Context: messages may be delayed, repeated or reordered. Decision: commit owner state and outbox together; consumers deduplicate event and business keys and record outcomes durably. Consequence: operators reconcile the original operation instead of repeating it with a new identity. Pending human completion is distinct from transport failure.

## Development approach

Use SDD to align requirements and contracts, DDD for the owner boundary, hexagonal ports/adapters for infrastructure independence, SOLID and clean code for cohesive responsibilities, and TDD for observable behavior. Avoid unnecessary abstraction. These practices do not change the five-service architecture.

## Pending implementation decisions

Verify component revisions, runtime manifests, migration tooling, environment configuration, broker binding/retry parameters, deployment procedure and provider/consumer tests. Do not infer implementation from repository names or the temporary prototype. See [readiness](../../service-readiness-checklist.md).

## Decision: justified manual care prices

Dentist/Administrator records an exact amount during authorized care with mandatory justification; Assistant cannot. No second approval threshold is required. Retained administrative correction APIs resolve unissued pricing problems only. Source uniqueness and immutable issued snapshots prevent double billing and historical repricing.
