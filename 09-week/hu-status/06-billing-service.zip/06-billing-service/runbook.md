# Runbook — Billing Service

Status: target procedures; no deployment, alarm threshold or successful recovery is claimed without [repository evidence](../../repository-evidence.md). Reviewed documentation date: 2026-09-25.

## 1. Quick information

| Field | Value |
|---|---|
| Service / owner | billing-service / Juan Diego Mora |
| Persistence | Shared PostgreSQL schema billing |
| Environment URLs, local port and dashboards | Not verified; obtain from the owner repository and deployment record |
| Escalation | Service owner, then the environment operator/Tech Lead; contact roster pending |
| Recovery objectives | Proposed project NFRs only; no measured service-specific RPO/RTO claimed |

## 2. Verify health

Check the private /health liveness and /health/ready readiness endpoints against their implemented contract. A running process does not prove database, owner authorization or broker readiness. Check recent deployments, connection errors, latency, error rate and outbox backlog using correlation IDs without credentials or clinical narrative. Public health responses expose only minimal status. Document actual paths and observations before staging acceptance.

## 3. Frequent alerts

### Charge remains pending

Verify completed clinical source and valid manual/catalog price. Missing information never creates a zero charge or invented approval.

### Duplicate source charge

Check procedure/source identity and idempotency record; manual and catalog prices must resolve one intended source.

### Payment rejected

Distinguish stale invoice version, invalid invoice state, overpayment and changed idempotency payload; never replay as a new payment blindly.

### Issued invoice differs from catalog

Read historical snapshots. Later catalog changes must not reprice an issued invoice.

### Assistant sees clinical narrative

Treat as authorization/minimization defect; restrict the response and investigate logs/caches. Financial labels must not copy protected clinical reasons.


## 4. Rollback

Identify the last verified compatible application artifact and its migration requirements. Assess data/event compatibility before redeploying it. Use a forward corrective migration when the old application cannot safely read the current schema. Preserve durable idempotency, outbox/inbox and audit state; never delete history or reset databases to clear an incident. Validate restored behavior using the original operation identity. Deployment commands remain pending repository verification.

## 5. Maintenance and migrations

Apply owner-reviewed migrations through the database component with a separate migration credential. Shared PostgreSQL changes coordinate the global sequence; Clinical MongoDB evolves independently. Back up and test restore before incompatible changes. Synthetic seeds are local/test only. Confirm business counts, indexes, grants, source references and worker backlog after change. Restart/replay workers idempotently and preserve unknown outcomes until the owner proves commit or abort.

Clinical/financial retention durations are pending institutional policy; no arbitrary purge. Security audit logs retain one year. Record selected migration tooling, artifact revision, operator, evidence and rollback/forward-recovery limits before deployment.

## 6. Post-incident

- Confirm affected health checks and representative authorized/denied operations.
- Reconcile unknown operations and ensure no duplicate charge, event or lifecycle transition.
- Verify logs contain no secrets or clinical narrative and preserve incident evidence.
- Record cause, mitigation, owner and follow-up in [incident management](../../../13-operations/incident-management.md).
- Attach measured recovery evidence; do not claim the proposed targets were achieved without it.
