# Events — Billing Service

This service publishes committed facts through its owned outbox. Canonical names and payload meaning come from [domain events](../../../02-domain/domain-events.md); this file describes owner integration, not new business semantics.

## Published events

| Event | Target exchange | Trigger | Payload fields |
|---|---|---|---|
| ManualChargeRecorded | billing.events | Dentist/Administrator commits a justified care-time price | chargeId, patientId, appointmentId, procedureId, sourceRecordId, recordedBy, recordedAt, version |
| BillableItemsCreated | billing.events | Billing idempotently resolves catalog or authorized justified manual prices and stores all base/additional charge snapshots for a completed procedure. | `procedureId`, `appointmentId`, `patientId`, `billableItemIds`, `total`, `currency`, `createdAt` |
| InvoiceIssued | billing.events | Authorized staff issue a valid draft containing at least one billable item. | `invoiceId`, `patientId`, `appointmentId?`, `total`, `currency`, `issuedAt`, `issuedBy` |
| PaymentRecorded | billing.events | Authorized staff record a valid internal/simulated payment. | `paymentId`, `invoiceId`, `patientId`, `amount`, `currency`, `remainingBalance`, `method`, `recordedAt`, `recordedBy` |
| InvoicePaid | billing.events | A payment reduces the outstanding balance to zero. | `invoiceId`, `patientId`, `paidAt` |

The exchange is a proposed transport name, not a verified broker configuration. Use the exact PascalCase event name as the target routing key; schema version is v1 under the current catalog. Bindings, queue credentials, retry limits and deployment confirmation remain readiness gates.

## Consumed events

| Event | Producer | Owner reaction |
|---|---|---|
| PatientDeactivated | Patients | Invalidate eligibility projections while preserving financial history. |
| AppointmentCancelled / AppointmentCompleted | Appointments | Reconcile source lifecycle without deleting charges or automatically issuing an invoice. |
| ConsultationRecorded | Clinical | Correlate care references only; do not create a duplicate billable item from this event. |
| ProcedureCompleted | Clinical | Reconcile unique clinical sources with catalog or justified manual prices and emit BillableItemsCreated. |
| ClinicalAssignmentStarted / ClinicalAssignmentEnded | Appointments | Invalidate access projections; validate current authority for Dentist charge entry. |

## Event schema and delivery guarantees

Use the existing envelope: eventId, eventType, aggregateId, aggregateType, occurredAt, version, producer, payload and metadata containing correlationId, causationId and actorUserId. Refer to the canonical catalog for exact field semantics. Publish only after a local state/outbox transaction commits. RabbitMQ is at least once; consumers use durable inbox/event and business-source deduplication before acknowledging.

Target consumer queues are scoped to the consuming owner and purpose, with matching retry/dead-letter queues. Retry transient failures with bounded backoff; isolate exhausted failures and reconcile the original operation. Do not create duplicate financial/clinical effects by replaying with new business IDs. Preserve correlation through recovery.

## Privacy and lifecycle

No credentials, raw confirmation tokens or clinical narrative belong in general-purpose events. Price justification remains protected Billing/Clinical owner data rather than a broadcast log. Assistant sees only necessary administrative/financial summaries. Analytics consumers are deferred.

Clinical relationship events invalidate projections but do not replace current authorization. ProcedureCompleted records readiness; appointment completion is an explicit Assistant/Administrator action. Waiting for it is pending, not message failure. Source uniqueness prevents manual/catalog duplicate charges.

## Correlations

- [Global event catalog](../../event-catalog.md).
- [Communication patterns](../../communication-patterns.md).
- [Data model](data-model.md) and [runbook](runbook.md).
